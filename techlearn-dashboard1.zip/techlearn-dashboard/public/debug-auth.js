// Debug script to help identify authentication button issues

console.log('Debug script loaded');

// Use a MutationObserver to monitor button clicks without interfering with existing event handlers
function setupButtonMonitoring() {
    console.log('Setting up button monitoring');
    
    // Function to log button state without adding event listeners
    function logButtonState(buttonId) {
        const button = document.getElementById(buttonId);
        if (button) {
            console.log(`Button state for ${buttonId}:`, {
                disabled: button.disabled,
                classList: Array.from(button.classList),
                style: button.style.cssText,
                parentVisible: button.parentElement.style.display !== 'none',
                boundEvents: button.onclick ? 'Has onclick handler' : 'No onclick handler'
            });
            return true;
        } else {
            console.error(`Button ${buttonId} not found in DOM`);
            return false;
        }
    }
    
    // Log initial state of all buttons
    console.log('Initial button states:');
    const loginBtnExists = logButtonState('login-btn');
    const registerBtnExists = logButtonState('register-btn');
    const connectGmailBtnExists = logButtonState('connect-gmail');
    
    // Set up a click monitor on the document to detect all clicks
    document.addEventListener('click', (e) => {
        const target = e.target;
        
        // Check if the click was on or inside one of our buttons
        if (target.id === 'login-btn' || target.closest('#login-btn')) {
            console.log('Login button or child clicked - debug monitor');
            console.log('Event:', e);
            logButtonState('login-btn');
        } else if (target.id === 'register-btn' || target.closest('#register-btn')) {
            console.log('Register button or child clicked - debug monitor');
            console.log('Event:', e);
            logButtonState('register-btn');
        } else if (target.id === 'connect-gmail' || target.closest('#connect-gmail')) {
            console.log('Connect Gmail button or child clicked - debug monitor');
            console.log('Event:', e);
            logButtonState('connect-gmail');
        }
    }, true); // Use capture phase to see all clicks before they reach their targets
}

// Call the setup function when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    setupButtonMonitoring();
    
    // Check if event propagation might be stopped
    document.body.addEventListener('click', (e) => {
        console.log('Body click event detected:', e.target);
    }, true); // Use capture phase to see all clicks
});