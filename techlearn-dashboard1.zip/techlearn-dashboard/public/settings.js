document.addEventListener('DOMContentLoaded', () => {
    console.log('[Settings] DOMContentLoaded: Script starting.');

    // --- ELEMENT SELECTORS ---
    const gmailStatus = document.getElementById('gmail-status');
    const connectGmailBtn = document.getElementById('connect-gmail');
    const disconnectGmailBtn = document.getElementById('disconnect-gmail');
    const authForm = document.getElementById('auth-form-settings');
    const messageElement = document.getElementById('message');

    // Login/Register form elements
    const loginBtn = document.getElementById('login-btn');
    const registerBtn = document.getElementById('register-btn');
    const showRegisterLink = document.getElementById('show-register');
    const showLoginLink = document.getElementById('show-login');
    const confirmPasswordInput = document.getElementById('confirm-password-input');

    // --- UI Update Function ---
    const updateUI = (status) => {
        console.log('[Settings] Updating UI with status:', status);
        // Hide everything by default
        if (authForm) authForm.style.display = 'none';
        if (connectGmailBtn) connectGmailBtn.style.display = 'none';
        if (disconnectGmailBtn) disconnectGmailBtn.style.display = 'none';

        if (status && status.email) {
            // User is logged in
            if (gmailStatus) gmailStatus.textContent = `Connected as: ${status.email}`;
            if (status.isGmailConnected) {
                if (disconnectGmailBtn) disconnectGmailBtn.style.display = 'block';
            } else {
                // Logged in via email/password, but can still connect Gmail
                if (connectGmailBtn) connectGmailBtn.style.display = 'block';
            }
        } else {
            // User is not logged in
            if (gmailStatus) gmailStatus.textContent = 'Not Connected';
            if (authForm) authForm.style.display = 'block';
            if (connectGmailBtn) connectGmailBtn.style.display = 'block';
        }
    };

    // --- API Call ---
    const checkStatusAndSetup = async () => {
        console.log('[Settings] Checking user status from API...');
        try {
            const response = await fetch('/api/user-status');
            if (response.ok) {
                const status = await response.json();
                updateUI(status);
            } else {
                console.log('[Settings] User not authenticated (API response not ok).');
                updateUI(null); // Not authenticated
            }
        } catch (error) {
            console.error('[Settings] Error checking user status API:', error);
            updateUI(null);
        }
    };

    // --- Event Handlers ---
    const handleLogin = async (e) => {
        e.preventDefault();
        console.log('[Settings] Login button clicked.');
        const email = document.getElementById('email-input').value;
        const password = document.getElementById('password-input').value;

        if (!email || !password) {
            if(messageElement) messageElement.textContent = 'Email and password are required.';
            return;
        }

        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password }),
                credentials: 'same-origin'
            });
            const data = await response.json();
            if (response.ok) {
                if(messageElement) messageElement.textContent = 'Logged in successfully!';
                window.location.reload(); // Reload the whole app to reflect login state
            } else {
                if(messageElement) messageElement.textContent = data.message || 'Login failed.';
            }
        } catch (error) {
            console.error('[Settings] Login fetch error:', error);
            if(messageElement) messageElement.textContent = 'Network error during login.';
        }
    };

    const handleRegister = async (e) => {
        e.preventDefault();
        console.log('[Settings] Register button clicked.');
        const email = document.getElementById('email-input').value;
        const password = document.getElementById('password-input').value;
        const confirmPassword = document.getElementById('confirm-password-input').value;

        if (password !== confirmPassword) {
            if(messageElement) messageElement.textContent = 'Passwords do not match!';
            return;
        }

        try {
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password }),
                credentials: 'same-origin'
            });
            const data = await response.json();
            if (response.ok) {
                if(messageElement) messageElement.textContent = 'Registration successful! Please log in.';
                toggleAuthForm(false);
            } else {
                if(messageElement) messageElement.textContent = data.message || 'Registration failed.';
            }
        } catch (error) {
            console.error('[Settings] Register fetch error:', error);
            if(messageElement) messageElement.textContent = 'Network error during registration.';
        }
    };

    const handleConnectGmail = (e) => {
        e.preventDefault();
        console.log('[Settings] Connect Gmail button clicked.');
        // Pass the current page to redirect back to after auth
        window.location.href = `/auth/google?redirect=${encodeURIComponent(window.location.pathname)}`;
    };

    const handleDisconnectGmail = async (e) => {
        e.preventDefault();
        console.log('[Settings] Disconnect Gmail button clicked.');
        try {
            await fetch('/api/disconnect', { method: 'POST' });
            window.location.reload();
        } catch (error) {
            console.error('[Settings] Error disconnecting:', error);
        }
    };

    const toggleAuthForm = (showRegister) => {
        console.log(`[Settings] Toggling auth form. Show register: ${showRegister}`);
        if(loginBtn) loginBtn.classList.toggle('hidden', showRegister);
        if(registerBtn) registerBtn.classList.toggle('hidden', !showRegister);
        if(confirmPasswordInput) confirmPasswordInput.classList.toggle('hidden', !showRegister);
        if(showRegisterLink) showRegisterLink.classList.toggle('hidden', showRegister);
        if(showLoginLink) showLoginLink.classList.toggle('hidden', !showRegister);
    };

    // --- Attach Event Listeners ---
    console.log('[Settings] Attaching event listeners...');
    if (loginBtn) loginBtn.addEventListener('click', handleLogin);
    if (registerBtn) registerBtn.addEventListener('click', handleRegister);
    if (connectGmailBtn) connectGmailBtn.addEventListener('click', handleConnectGmail);
    if (disconnectGmailBtn) disconnectGmailBtn.addEventListener('click', handleDisconnectGmail);
    if (showRegisterLink) showRegisterLink.addEventListener('click', (e) => { e.preventDefault(); toggleAuthForm(true); });
    if (showLoginLink) showLoginLink.addEventListener('click', (e) => { e.preventDefault(); toggleAuthForm(false); });

    // --- Initial Load ---
    console.log('[Settings] Calling checkStatusAndSetup on load.');
    checkStatusAndSetup();
});