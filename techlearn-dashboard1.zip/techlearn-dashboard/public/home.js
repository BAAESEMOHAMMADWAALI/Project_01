document.addEventListener('DOMContentLoaded', function() {
    const courseGrid = document.querySelector('.course-grid');
    const scheduleBody = document.getElementById('schedule-body');

    // Load saved data
    loadSavedData();

    // Function to create a unique ID from a string
    function createId(str) {
        return str.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') + '-' + Date.now();
    }

    // Function to save data to localStorage
    function saveData() {
        const courses = [];
        const schedule = [];

        // Save courses
        document.querySelectorAll('.course-card').forEach(card => {
            courses.push({
                id: card.dataset.id,
                title: card.querySelector('h4').textContent,
                progress: card.querySelector('.progress-fill').dataset.progress,
                completed: card.querySelector('.complete-btn').classList.contains('completed')
            });
        });

        // Save schedule
        document.querySelectorAll('#schedule-body tr').forEach(row => {
            schedule.push({
                id: row.dataset.id,
                time: row.cells[0].textContent,
                course: row.cells[1].textContent,
                days: row.cells[2].textContent
            });
        });

        localStorage.setItem('techlearn-courses', JSON.stringify(courses));
        localStorage.setItem('techlearn-schedule', JSON.stringify(schedule));
    }

    // Function to load saved data
    function loadSavedData() {
        try {
            const courses = JSON.parse(localStorage.getItem('techlearn-courses')) || [];
            const schedule = JSON.parse(localStorage.getItem('techlearn-schedule')) || [];

            courses.forEach(course => {
                const id = addCourse(course.title, course.progress);
                const card = document.querySelector(`.course-card[data-id="${id}"]`);
                if (card && course.completed) {
                    const completeBtn = card.querySelector('.complete-btn');
                    completeBtn.textContent = 'Completed';
                    completeBtn.classList.add('completed');
                    card.querySelector('p').textContent = '● Completed';
                }
            });

            schedule.forEach(item => {
                addScheduleRow(item.id, item.time, item.course, item.days);
            });
        } catch (error) {
            console.error('Error loading saved data:', error);
            showFeedback('Error loading saved data.', true);
        }
    }

    // Add auto-save after modifications
    const autoSave = () => {
        saveData();
        showFeedback('Changes saved.');
    };

    // Modify existing event listeners to include auto-save
    courseGrid.addEventListener('click', function(e) {
        const target = e.target;
        const card = target.closest('.course-card');
        if (!card) return;

        // After any modification to courses
        if (target.matches('.complete-btn, .reset-btn, .delete-btn')) {
            setTimeout(autoSave, 100); // Small delay to ensure DOM updates are complete
        }
    });

    scheduleBody.addEventListener('click', function(e) {
        if (e.target.classList.contains('action-btn')) {
            setTimeout(autoSave, 100);
        }
    });

    // Update makeEditable function for better sync
    function makeEditable(cell, type) {
        const row = cell.closest('tr');
        const id = row.dataset.id;
        const text = cell.textContent;
        const input = document.createElement('input');
        
        input.type = 'text';
        input.value = text;
        input.style.cssText = 'background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(255, 255, 255, 0.2); color: white; padding: 5px; border-radius: 5px; width: 100%;';
        
        cell.innerHTML = '';
        cell.appendChild(input);
        input.focus();

        const updateBothSections = (newValue) => {
            // Update schedule
            cell.textContent = newValue;
            
            // Update course card
            if (type === 'course') {
                const courseCard = document.querySelector(`.course-card[data-id="${id}"]`);
                if (courseCard) {
                    courseCard.querySelector('h4').textContent = newValue;
                }
            }
            autoSave();
        };

        input.addEventListener('blur', () => {
            const newValue = input.value.trim();
            if (!newValue) {
                showFeedback('Field cannot be empty.', true);
                input.focus();
                return;
            }
            updateBothSections(newValue);
        });

        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const newValue = input.value.trim();
                if (!newValue) {
                    showFeedback('Field cannot be empty.', true);
                    return;
                }
                updateBothSections(newValue);
                input.blur();
            }
        });
    }

    // Function to add a new course to the grid
    function addCourse(title, progress) {
        const id = createId(title);
        const newCourse = document.createElement('div');
        newCourse.classList.add('course-card');
        newCourse.dataset.id = id;
        newCourse.innerHTML = `
            <h4>${title}</h4>
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${progress}%;" data-progress="${progress}"></div>
            </div>
            <p>${progress}% Complete</p>
            <div class="course-card-buttons">
                <button class="complete-btn">Mark Complete</button>
                <button class="reset-btn">Reset</button>
                <button class="delete-btn">Delete</button>
                <div class="suggestion-container">
                    <button class="suggestion-btn">...</button>
                    <div class="suggestion-popup">
                        <a href="course-suggestion.html">New Course Suggestions</a>
                    </div>
                </div>
            </div>
        `;
        courseGrid.appendChild(newCourse);
        return id;
    }

    // Function to add a new row to the schedule
    function addScheduleRow(id, time, course, days) {
        const newRow = document.createElement('tr');
        newRow.dataset.id = id;
        newRow.innerHTML = `
            <td>${time}</td>
            <td>${course}</td>
            <td>${days}</td>
            <td class="action-buttons">
                <button class="action-btn">✏️</button>
                <button class="action-btn">🗑️</button>
            </td>
        `;
        scheduleBody.appendChild(newRow);
        return newRow;
    }

    // Add Study Slot button
    document.querySelector('.add-slot-btn').addEventListener('click', function() {
        const id = `new-course-${Date.now()}`;
        const newRow = addScheduleRow(id, '16:00 - 17:30', 'New Course', '7 days');
        const courseCell = newRow.querySelector('td:nth-child(2)');
        makeEditable(courseCell, 'course');
        addCourse('New Course', 0);
    });

    // Event delegation for course card buttons
    courseGrid.addEventListener('click', function(e) {
        const target = e.target;
        const card = target.closest('.course-card');
        if (!card) return;

        const id = card.dataset.id;
        const progressBar = card.querySelector('.progress-fill');
        const progressText = card.querySelector('p');
        const completeBtn = card.querySelector('.complete-btn');

        // Mark/Undo Complete button
        if (target.classList.contains('complete-btn')) {
            if (target.classList.contains('completed')) {
                // Undo complete
                const originalProgress = progressBar.dataset.progress || 0;
                progressBar.style.width = `${originalProgress}%`;
                progressText.textContent = `${originalProgress}% Complete`;
                target.textContent = 'Mark Complete';
                target.classList.remove('completed');
                // Add back to schedule
                const scheduleRow = document.querySelector(`#schedule-body tr[data-id="${id}"]`);
                if (!scheduleRow) {
                    const courseTitle = card.querySelector('h4').textContent;
                    addScheduleRow(id, '00:00 - 00:00', courseTitle, 'N/A');
                    showFeedback('Course restored to schedule.');
                }
            } else {
                // Mark complete
                progressBar.dataset.progress = progressBar.style.width.replace('%', '');
                progressBar.style.width = '100%';
                progressText.textContent = '● Completed';
                target.textContent = 'Completed';
                target.classList.add('completed');
                // Remove from schedule
                const scheduleRow = document.querySelector(`#schedule-body tr[data-id="${id}"]`);
                if (scheduleRow) {
                    scheduleRow.remove();
                    showFeedback('Course marked as complete.');
                }
            }
        }

        // Reset button
        if (target.classList.contains('reset-btn')) {
            progressBar.style.width = '0%';
            progressBar.dataset.progress = 0;
            progressText.textContent = '0% Complete';
            completeBtn.textContent = 'Mark Complete';
            completeBtn.classList.remove('completed');
            // Add back to schedule if it was completed
            const scheduleRow = document.querySelector(`#schedule-body tr[data-id="${id}"]`);
            if (!scheduleRow) {
                const courseTitle = card.querySelector('h4').textContent;
                addScheduleRow(id, '00:00 - 00:00', courseTitle, 'N/A');
                showFeedback('Course progress reset.');
            }
        }

        // Delete button
        if (target.classList.contains('delete-btn')) {
            if (confirm('Are you sure you want to delete this course? This will remove it from both sections.')) {
                card.remove();
                const scheduleRow = document.querySelector(`#schedule-body tr[data-id="${id}"]`);
                if (scheduleRow) {
                    scheduleRow.remove();
                }
                showFeedback('Course deleted successfully.');
            }
        }
    });

    // Action buttons (edit and delete)
    scheduleBody.addEventListener('click', function(e) {
        if (e.target.classList.contains('action-btn')) {
            const row = e.target.closest('tr');
            const id = row.dataset.id;
            const isEdit = e.target.textContent === '✏️';

            if (isEdit) {
                const cells = row.querySelectorAll('td');
                makeEditable(cells[1], 'course'); // Course name
                makeEditable(cells[2], 'days');  // Days
                showFeedback('You can now edit the course name or days.');
            } else {
                if (confirm('Are you sure you want to delete this schedule entry? This will remove the course from both sections.')) {
                    row.remove();
                    const courseCard = document.querySelector(`.course-card[data-id="${id}"]`);
                    if (courseCard) {
                        courseCard.remove();
                    }
                    showFeedback('Schedule entry deleted successfully.');
                }
            }
        }
    });

    // Tooltip for all action buttons
    document.body.addEventListener('mouseover', function(e) {
        if (e.target.classList.contains('complete-btn')) {
            e.target.title = e.target.classList.contains('completed') ? 'Undo Complete' : 'Mark as Complete';
        }
        if (e.target.classList.contains('reset-btn')) {
            e.target.title = 'Reset progress and re-add to schedule';
        }
        if (e.target.classList.contains('delete-btn')) {
            e.target.title = 'Delete this course';
        }
        if (e.target.classList.contains('action-btn')) {
            e.target.title = e.target.textContent === '✏️' ? 'Edit course or days' : 'Delete this schedule entry';
        }
    });

    // Visual feedback function
    function showFeedback(message, isError) {
        let feedback = document.getElementById('feedback-message');
        if (!feedback) {
            feedback = document.createElement('div');
            feedback.id = 'feedback-message';
            feedback.style.position = 'fixed';
            feedback.style.bottom = '30px';
            feedback.style.left = '50%';
            feedback.style.transform = 'translateX(-50%)';
            feedback.style.padding = '12px 24px';
            feedback.style.borderRadius = '8px';
            feedback.style.background = isError ? 'rgba(255, 0, 0, 0.8)' : 'rgba(0, 128, 0, 0.8)';
            feedback.style.color = 'white';
            feedback.style.fontWeight = 'bold';
            feedback.style.zIndex = 9999;
            document.body.appendChild(feedback);
        }
        feedback.textContent = message;
        feedback.style.display = 'block';
        setTimeout(() => {
            feedback.style.display = 'none';
        }, 2000);
    }

    // Function to sync course and schedule
    function syncCourseAndSchedule(id, action) {
        const courseCard = document.querySelector(`.course-card[data-id="${id}"]`);
        const scheduleRow = document.querySelector(`#schedule-body tr[data-id="${id}"]`);

        if (!courseCard) {
            showFeedback('Error: Course not found.', true);
            return false;
        }

        if (action === 'delete') {
            courseCard.remove();
            if (scheduleRow) scheduleRow.remove();
            return true;
        }

        return true;
    }

    // Update delete button handlers to use sync function
    courseGrid.addEventListener('click', function(e) {
        const target = e.target;
        const card = target.closest('.course-card');
        if (!card) return;

        const id = card.dataset.id;

        // Delete button
        if (target.classList.contains('delete-btn')) {
            if (confirm('Are you sure you want to delete this course? This will remove it from both sections.')) {
                if (syncCourseAndSchedule(id, 'delete')) {
                    showFeedback('Course deleted successfully.');
                }
            }
        }
    });

    // Update schedule delete handler
    scheduleBody.addEventListener('click', function(e) {
        if (e.target.classList.contains('action-btn')) {
            const row = e.target.closest('tr');
            const id = row.dataset.id;
            const isEdit = e.target.textContent === '✏️';

            if (!isEdit) {
                if (confirm('Are you sure you want to delete this schedule entry? This will remove the course from both sections.')) {
                    if (syncCourseAndSchedule(id, 'delete')) {
                        showFeedback('Schedule entry deleted successfully.');
                    }
                }
            }
        }
    });

    // Improved deletion sync function
    function deleteFromBothSections(id) {
        return new Promise((resolve) => {
            const courseCard = document.querySelector(`.course-card[data-id="${id}"]`);
            const scheduleRow = document.querySelector(`#schedule-body tr[data-id="${id}"]`);
            
            if (courseCard) {
                courseCard.style.opacity = '0';
                courseCard.style.transform = 'scale(0.9)';
                setTimeout(() => {
                    courseCard.remove();
                }, 300);
            }
            
            if (scheduleRow) {
                scheduleRow.style.opacity = '0';
                setTimeout(() => {
                    scheduleRow.remove();
                }, 300);
            }

            setTimeout(() => {
                autoSave();
                showFeedback('Course deleted successfully.');
                resolve();
            }, 300);
        });
    }

    // Update event listeners for deletion
    document.addEventListener('click', async function(e) {
        // Delete from course card
        if (e.target.classList.contains('delete-btn')) {
            const card = e.target.closest('.course-card');
            if (!card) return;
            
            const id = card.dataset.id;
            if (confirm('Are you sure you want to delete this course? This will remove it from both sections.')) {
                await deleteFromBothSections(id);
            }
        }
        
        // Delete from schedule
        if (e.target.classList.contains('action-btn') && e.target.textContent === '🗑️') {
            const row = e.target.closest('tr');
            if (!row) return;
            
            const id = row.dataset.id;
            if (confirm('Are you sure you want to delete this course? This will remove it from both sections.')) {
                await deleteFromBothSections(id);
            }
        }
    });

    // Add slider navigation
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    // Use the already declared courseGrid variable

    prevBtn.addEventListener('click', () => {
        courseGrid.scrollBy({ left: -320, behavior: 'smooth' });
    });

    nextBtn.addEventListener('click', () => {
        courseGrid.scrollBy({ left: 320, behavior: 'smooth' });
    });

    // Add this code for the carousel
    document.addEventListener('DOMContentLoaded', function() {
        const courseGrid = document.querySelector('.course-grid');
        const prevBtn = document.querySelector('.prev-btn');
        const nextBtn = document.querySelector('.next-btn');
        const cardWidth = 320; // Width of card + gap

        function updateNavigationButtons() {
            const isAtStart = courseGrid.scrollLeft <= 0;
            const isAtEnd = courseGrid.scrollLeft >= (courseGrid.scrollWidth - courseGrid.clientWidth - 10);
            
            prevBtn.style.opacity = isAtStart ? '0.5' : '1';
            prevBtn.style.cursor = isAtStart ? 'default' : 'pointer';
            
            nextBtn.style.opacity = isAtEnd ? '0.5' : '1';
            nextBtn.style.cursor = isAtEnd ? 'default' : 'pointer';
        }

        prevBtn.addEventListener('click', () => {
            courseGrid.scrollBy({ left: -cardWidth, behavior: 'smooth' });
        });

        nextBtn.addEventListener('click', () => {
            courseGrid.scrollBy({ left: cardWidth, behavior: 'smooth' });
        });

        courseGrid.addEventListener('scroll', updateNavigationButtons);
        updateNavigationButtons();
    });
});