async function startAI() {
    const email = document.getElementById('email').value;
    const course = document.getElementById('course').value;
    const days = document.getElementById('days').value;
    const schedule = document.getElementById('schedule').value;
    const interests = document.getElementById('interests').value;

    if (!email || !course || !days || !schedule) {
        alert('Please fill in all required fields!');
        return;
    }

    const btn = document.querySelector('.start-btn');
    const originalBtnText = btn.innerHTML;
    btn.innerHTML = ' Setting up your AI...';
    btn.disabled = true;

    try {
        const response = await fetch('/api/study-plan/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ courseName: course, totalDays: parseInt(days) })
        });

        const data = await response.json();

        if (response.ok) {
            btn.innerHTML = '✅ AI Assistant Activated!';
            btn.style.background = 'linear-gradient(45deg, #10b981, #059669)';
            alert(` Welcome to TechFlow AI:\n\nYour personalized learning assistant is now active!\n\n Email: ${email}\n Course: ${course} (${days} days)\n⏰ Schedule: ${schedule}\n\n${data.message || 'You\'ll receive your first digest within 24 hours!'}`);
        } else {
            btn.innerHTML = originalBtnText;
            btn.disabled = false;
            alert(`Error setting up AI: ${data.message || 'Something went wrong.'}`);
        }
    } catch (error) {
        console.error('Error during AI setup:', error);
        btn.innerHTML = originalBtnText;
        btn.disabled = false;
        alert('An error occurred during AI setup. Please try again.');
    }
}

'''document.addEventListener('DOMContentLoaded', () => {
    const loginPopup = document.getElementById('login-popup');
    const closePopup = document.getElementById('close-popup');
    const googleLoginBtn = document.getElementById('google-login-btn');
    const loginBtn = document.getElementById('login-btn');
    const registerBtn = document.getElementById('register-btn');
    const confirmPasswordInput = document.getElementById('confirm-password-input');
    const showRegisterLink = document.getElementById('show-register');
    const showLoginLink = document.getElementById('show-login');
    const studyScheduleList = document.getElementById('study-schedule-list');
    const coursesInProgressList = document.getElementById('courses-in-progress-list');

    const fetchAndDisplayCourses = async () => {
        try {
            const response = await fetch('/api/courses');
            if (!response.ok) {
                if (response.status === 401) {
                    console.log('User not authenticated. Skipping course display.');
                    return;
                }
                throw new Error('Failed to fetch courses.');
            }
            const courses = await response.json();
            
            studyScheduleList.innerHTML = '';
            coursesInProgressList.innerHTML = '';

            if (courses.length === 0) {
                studyScheduleList.innerHTML = '<li>No courses added yet.</li>';
                coursesInProgressList.innerHTML = '<li>No courses in progress.</li>';
                return;
            }

            courses.forEach(course => {
                addCourseToLists(course);
            });
        } catch (error) {
            console.error('Error fetching courses:', error);
            studyScheduleList.innerHTML = '<li>Error loading courses.</li>';
            coursesInProgressList.innerHTML = '<li>Error loading courses.</li>';
        }
    };

    const addCourseToLists = (course) => {
        const scheduleLi = document.createElement('li');
        scheduleLi.dataset.courseId = course.id;
        scheduleLi.innerHTML = `
            <span class="course-name">${course.name}</span>
            <div class="course-actions">
                <button class="edit-btn">Edit</button>
                <button class="delete-btn">Delete</button>
            </div>
        `;
        studyScheduleList.appendChild(scheduleLi);

        const progressLi = document.createElement('li');
        progressLi.dataset.courseId = course.id;
        progressLi.innerHTML = `<span class="course-name">${course.name}</span>`;
        coursesInProgressList.appendChild(progressLi);
    };

    const handleAddCourse = async () => {
        const courseName = prompt('Enter the new course name:');
        if (courseName && courseName.trim() !== '') {
            try {
                const response = await fetch('/api/courses', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: courseName.trim() })
                });
                if (response.ok) {
                    const newCourse = await response.json();
                    addCourseToLists(newCourse);
                } else {
                    throw new Error('Failed to add course.');
                }
            } catch (error) {
                console.error('Error adding course:', error);
                alert('Error adding course.');
            }
        }
    };

    const handleEditCourse = async (courseId, courseNameSpan) => {
        const newName = prompt('Enter the new course name:', courseNameSpan.textContent);
        if (newName && newName.trim() !== '' && newName.trim() !== courseNameSpan.textContent) {
            try {
                const response = await fetch(`/api/courses/${courseId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: newName.trim() })
                });
                if (response.ok) {
                    document.querySelectorAll(`[data-course-id='${courseId}'] .course-name`).forEach(span => {
                        span.textContent = newName.trim();
                    });
                } else {
                    throw new Error('Failed to update course.');
                }
            } catch (error) {
                console.error('Error updating course:', error);
                alert('Error updating course.');
            }
        }
    };

    const handleDeleteCourse = async (courseId) => {
        if (confirm('Are you sure you want to delete this course?')) {
            try {
                const response = await fetch(`/api/courses/${courseId}`, {
                    method: 'DELETE'
                });
                if (response.ok) {
                    document.querySelectorAll(`[data-course-id='${courseId}']`).forEach(el => el.remove());
                } else {
                    throw new Error('Failed to delete course.');
                }
            } catch (error) {
                console.error('Error deleting course:', error);
                alert('Error deleting course.');
            }
        }
    };

    studyScheduleList.addEventListener('click', (e) => {
        const target = e.target;
        const li = target.closest('li');
        if (!li) return;

        const courseId = li.dataset.courseId;
        if (target.classList.contains('edit-btn')) {
            const courseNameSpan = li.querySelector('.course-name');
            handleEditCourse(courseId, courseNameSpan);
        } else if (target.classList.contains('delete-btn')) {
            handleDeleteCourse(courseId);
        }
    });

    const addCourseBtn = document.createElement('button');
    addCourseBtn.textContent = 'Add Course';
    addCourseBtn.classList.add('add-course-btn');
    addCourseBtn.addEventListener('click', handleAddCourse);
    studyScheduleList.insertAdjacentElement('afterend', addCourseBtn);

    const checkUserStatus = async () => {
        try {
            const response = await fetch('/api/user-status');
            const data = await response.json();
            if (data.email) {
                fetchAndDisplayCourses();
            } else {
                loginPopup.style.display = 'flex';
            }
        } catch (error) {
            console.error('Error checking user status:', error);
            loginPopup.style.display = 'flex';
        }
    };

    closePopup.addEventListener('click', () => {
        loginPopup.style.display = 'none';
    });

    googleLoginBtn.addEventListener('click', () => {
        window.location.href = '/auth/google';
    });

    loginBtn.addEventListener('click', async () => {
        const email = document.getElementById('email-input').value;
        const password = document.getElementById('password-input').value;

        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await response.json();
            if (response.ok) {
                alert(data.message);
                loginPopup.style.display = 'none';
                fetchAndDisplayCourses();
            } else {
                alert(data.message);
            }
        } catch (error) {
            console.error('Error during login:', error);
            alert('An error occurred during login.');
        }
    });

    const toggleToRegister = () => {
        loginBtn.classList.add('hidden');
        registerBtn.classList.remove('hidden');
        confirmPasswordInput.classList.remove('hidden');
        showRegisterLink.classList.add('hidden');
        showLoginLink.classList.remove('hidden');
    };

    const toggleToLogin = () => {
        loginBtn.classList.remove('hidden');
        registerBtn.classList.add('hidden');
        confirmPasswordInput.classList.add('hidden');
        showRegisterLink.classList.remove('hidden');
        showLoginLink.classList.add('hidden');
    };

    showRegisterLink.addEventListener('click', toggleToRegister);
    showLoginLink.addEventListener('click', toggleToLogin);

    registerBtn.addEventListener('click', async () => {
        const email = document.getElementById('email-input').value;
        const password = document.getElementById('password-input').value;
        const confirmPassword = document.getElementById('confirm-password-input').value;

        if (password !== confirmPassword) {
            alert('Passwords do not match!');
            return;
        }

        try {
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await response.json();
            if (response.ok) {
                alert(data.message);
                loginPopup.style.display = 'none';
                fetchAndDisplayCourses();
            } else {
                alert(data.message);
            }
        } catch (error) {
            console.error('Error during registration:', error);
            alert('An error occurred during registration.');
        }
    });

    // Initial setup
    checkUserStatus();
});
''