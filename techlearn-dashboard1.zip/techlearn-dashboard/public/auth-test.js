document.addEventListener('DOMContentLoaded', () => {
    const loginBtn = document.getElementById('login-btn');
    const connectGmailBtn = document.getElementById('connect-gmail');
    const messageElement = document.getElementById('message');

    async function handleLogin(event) {
        event.preventDefault();
        const email = document.getElementById('email-input').value;
        const password = document.getElementById('password-input').value;

        if (!email || !password) {
            messageElement.textContent = 'Email and password are required.';
            return;
        }

        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password }),
                credentials: 'same-origin'
            });
            const data = await response.json();
            if (response.ok) {
                messageElement.textContent = 'Logged in successfully!';
            } else {
                messageElement.textContent = data.message || 'Login failed.';
            }
        } catch (error) {
            console.error('Login error:', error);
            messageElement.textContent = 'Network error during login.';
        }
    }

    function handleConnectGmail(event) {
        event.preventDefault();
        const redirectUrl = `/auth/google?redirect=${encodeURIComponent(window.location.pathname)}`;
        window.location.href = redirectUrl;
    }

    if (loginBtn) {
        loginBtn.addEventListener('click', handleLogin);
    }

    if (connectGmailBtn) {
        connectGmailBtn.addEventListener('click', handleConnectGmail);
    }
});